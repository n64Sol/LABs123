# Licensing Notes — Universal LPC Spritesheet Assets

> Feasibility gate for using these assets in **Labyrinths** (a commercial, Solana-ready game).
> **Read this before building an item library or shipping any composed sprite.**

## TL;DR verdict

- **Usable? Yes** — LPC art permits commercial use, including in a paid/Solana game.
- **Free of obligations? No.** Essentially every LPC layer requires **attribution**, and many are
  **ShareAlike / copyleft (CC-BY-SA, GPL)**, which imposes obligations on the *art you distribute*.
- **Biggest risk for this project:** selling the **art itself as exclusive/proprietary assets**
  (e.g. minting sprites as NFTs and claiming exclusivity) **conflicts with ShareAlike**. Selling a
  *game* that uses the art is fine as long as attribution + ShareAlike on the art are honored.

## CRITICAL GAP in this asset dump

This dump contains **only the spritesheet PNGs** (24,745 of them). It is **missing all license and
attribution metadata**:

- ❌ No `sheet_definitions/*.json` (the LPC generator files that record each asset's **authors** and **licenses**)
- ❌ No `CREDITS.csv` / `CREDITS.txt`
- ❌ No `LICENSE` files
- ❌ No per-category attribution

**Consequence:** we cannot currently produce a legally-complete credits file from this dump alone.
The per-asset authors and license terms **must be reconstructed** from the official source (see below)
before shipping. This is a real, must-do step — not a formality.

## How LPC licensing works

LPC assets are **multi-licensed**. A given layer is typically released under **one or more** of:

| License | Commercial use | Attribution required | ShareAlike / copyleft |
|---|---|---|---|
| CC-BY-SA 3.0 (and 4.0) | ✅ | ✅ | ✅ (derivatives must be CC-BY-SA) |
| GPL 3.0 (and 2.0) | ✅ | ✅ | ✅ (copyleft) |
| CC-BY 4.0 / 3.0 | ✅ | ✅ | ❌ (no ShareAlike) |
| OGA-BY 3.0 | ✅ | ✅ | ❌ |
| CC0 (rare) | ✅ | ❌ | ❌ |

Each asset lists its **own** set of authors and licenses. To comply, you pick the license that suits
you **from the set offered for that specific asset**, and follow it.

### What this means for a composed character sprite
A composed sprite (like the included *Sunlit Adventurer*) is a derivative of **every** layer it uses.
Its obligations are the **union** of all layer licenses:
- You must **credit every author of every layer** used.
- If **any** layer is **only** available under CC-BY-SA or GPL, the **composed sprite inherits
  ShareAlike/copyleft** — i.e. you must offer that sprite under a compatible copyleft license, and you
  cannot make *that art* proprietary/exclusive.
- To **avoid** ShareAlike, you must restrict yourself to layers that are *also* offered under a
  permissive license (CC-BY / OGA-BY / CC0) and consistently use that option.

## Practical guidance for Labyrinths

1. **Your game code is unaffected.** Art licenses (CC-BY-SA/GPL-for-art) do **not** bleed into your
   TypeScript/server logic. The copyleft attaches to the **art assets**, not your codebase.
2. **Maintain a CREDITS file** that ships with the game and lists, per asset used: author(s), license,
   and source URL. (Template in `credits.txt`.)
3. **Reconstruct metadata first.** Before generating an item library, pull `sheet_definitions/` from the
   official Universal-LPC-Spritesheet-Character-Generator repo and map each path used → authors+licenses.
4. **If you want to avoid ShareAlike** (e.g. for selling/minting exclusive art): build an allowlist of
   only CC-BY / OGA-BY / CC0 assets and compose strictly from it. Verify per-asset before inclusion.
5. **Solana / NFT caution:** minting LPC-derived sprites as **exclusive** tradable assets is
   **incompatible with CC-BY-SA/GPL** layers (ShareAlike forbids exclusivity on the art). Either
   (a) restrict to permissive-only layers, or (b) keep sprites as in-game cosmetics (not sold as
   exclusive art), or (c) commission/replace those specific layers.

## Sources to reconstruct attribution
- Official generator + metadata: `Universal-LPC-Spritesheet-Character-Generator` (sheet_definitions/, CREDITS.csv)
- OpenGameArt LPC collection pages (per-asset author + license)
- The original LPC contest page (base authors: Stephen Challener / Redshrike, Johannes Sjölund / wulax, and many others)

---
*This is an engineering feasibility summary, not legal advice. Confirm per-asset terms against the
official metadata before commercial release.*
